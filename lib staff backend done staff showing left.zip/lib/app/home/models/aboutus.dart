import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class AboutusPage extends StatefulWidget {
  @override
  _AboutusPageState createState() => _AboutusPageState();
}

class _AboutusPageState extends State<AboutusPage> {


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
      title: Center(child: Text('About Us       ')),
    ),
      body: SingleChildScrollView(
    child: Column(
    children: <Widget>[
      SizedBox(
      height: 50,
    ),
    Text("About Us ",
    style: TextStyle(color: Colors.black87,
    fontSize: 30,
    fontWeight: FontWeight.bold),
    textAlign: TextAlign.center),
    SizedBox(
    height: 20,
    ),
    Image.asset(
    "images/about.jpg",
    fit: BoxFit.cover,
    width: double.infinity,
    ),
    SizedBox(
    height: 35,
    ),
    Text("HMS is a hospital management system where user can book his or her appointments whenever and wherever from the user want."
    "User will gets its all appointment history along with all the medical presicriptions prescribe by the doctor till now."
    "User can also see its billing history", textAlign: TextAlign.center, style: TextStyle(fontSize: 30, height: 1.2, letterSpacing: 1,  fontWeight: FontWeight.bold),),
    ],
    ),
    ),
    );

  }
}