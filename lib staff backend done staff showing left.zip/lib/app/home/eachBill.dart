import 'package:flutter/material.dart';
import 'package:time_tracker_flutter_course/app/home/models/bill.dart';

class EachBill extends StatefulWidget {
  final Bill bill;

  const EachBill({Key key, this.bill}) : super(key: key);
  @override
  _EachBillState createState() => _EachBillState();
}

class _EachBillState extends State<EachBill> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Center(child: Text(widget.bill.title)),
      ),
      body: Column(
        children: [
          Text(widget.bill.title),
          Text("The cost for your "+widget.bill.title+" is billed for Rs."+widget.bill.cost.toString()),
          Text("Your appointment was dated for "+widget.bill.date.toString()),
        ],
      ),
    );
  }
}
