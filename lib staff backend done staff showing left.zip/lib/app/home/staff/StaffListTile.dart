import 'package:flutter/material.dart';
import 'package:time_tracker_flutter_course/app/home/staff/StaffModel.dart';

class StaffListTile extends StatelessWidget  {
  final StaffModel staff;
  final VoidCallback onTap;

  const StaffListTile({Key key, this.staff, this.onTap}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return ListTile(
      title: Padding(
        padding: const EdgeInsets.symmetric(vertical: 8.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text("Name: "+staff.name),
            SizedBox(height: 3,),
            Text("Experience: "+staff.exp.toString()+" years"),
            SizedBox(height: 3,),
            Text("Speciality: "+staff.profession),
          ],
        ),
      ),
      trailing: Icon(Icons.chevron_right),
      onTap: onTap,
    );
  }
}
