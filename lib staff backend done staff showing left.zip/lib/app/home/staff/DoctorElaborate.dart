import 'package:flutter/material.dart';
import 'package:time_tracker_flutter_course/app/home/staff/StaffModel.dart';

class DoctorElaborate extends StatelessWidget  {
  final StaffModel staff;

  const DoctorElaborate({Key key, this.staff}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Center(child: Text('${staff.id}         ')),
      ),
      body: Column(
        children: [
          Text("Experience: "+staff.exp.toString())
        ],
      ),

    );
  }
}
