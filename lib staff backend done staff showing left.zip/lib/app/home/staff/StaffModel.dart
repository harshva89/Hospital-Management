import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class StaffModel{
  StaffModel({@required this.id, @required this.name, @required this.profession, @required this.exp});
  final String id;
  final String name;
  final String profession;
  final int exp;

  factory StaffModel.fromMap(Map<String, dynamic> data, String documentId){
    if(data == null){
      return null;
    }
    final String name = data['name'];
    final String profession = data['profession'];
    final int exp = data['exp'];
    return StaffModel(
      id: documentId,
      name: name,
      profession: profession,
      exp: exp,
    );
  }

  Map<String, dynamic> toMap(){
    return {
      'name':name,
      'profession':profession,
      'exp':exp,
    };
  }
}